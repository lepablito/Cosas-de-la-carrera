package my.television;

import my.teleModelo.ModeloT;
import my.teleVista.StateMachine;

/**
 * @author javdepr
 * @author pabmarc
 */
public class Main {

    public static StateMachine television;
    private static ModeloT modelo;
        
        public static void main(String args[]) {
            modelo=new ModeloT();
            television=new StateMachine(modelo);
        }
        
    public static StateMachine getTelevision(){
            return television;
    }
}
