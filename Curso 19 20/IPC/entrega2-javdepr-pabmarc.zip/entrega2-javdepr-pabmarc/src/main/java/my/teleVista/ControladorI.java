package my.teleVista;

import my.teleModelo.ModeloT;

/**
 * Controlador de la interfaz sencilla de la configuración de imagen de un televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see VistaImagen
 */
public class ControladorI {


    private final VistaImagen vista;
    private final ModeloT modelo;
     /**
     * Constructor del controlador de la configuracion de imagen, se declaran el modelo usado y la vista de la configuracion.
     * 
     * @param v La vista usada en la configuracion de imagen.
     * @param m El modelo de la aplicación.
     */
    public ControladorI(VistaImagen v, ModeloT m){
        vista = v;
        modelo = m;
    }
    /**
     * Llama a los metodos del modelo y la vista para cambiar el valor de la nitidez.
     * @param value El valor entero de la nitidez (0-100)
     * @see ModeloT#setNitidez(int) 
     * @see VistaImagen#cambiaNitidez(int) 
     */
    void procesaNitidez(int value) {
        modelo.setNitidez(value);
        vista.cambiaNitidez(value);
    }
    /**
     * Llama a los metodos del modelo y la vista para cambiar el valor del contraste.
     * @param value El valor entero del contraste (0-100)
     * @see ModeloT#setContraste(int) 
     * @see VistaImagen#cambiaContraste(int) 
     */
    void procesaContraste(int value) {
        modelo.setContraste(value);
        vista.cambiaContraste(value);
    }
    /**
     * Llama a los metodos del modelo y la vista para cambiar el valor del brillo.
     * @param value El valor entero del brillo (0-100)
     * @see ModeloT#setBrillo(int) 
     * @see VistaImagen#cambiaBrillo(int) 
     */
    void procesaBrillo(int value) {
        modelo.setBrillo(value);
        vista.cambiaBrillo(value);
    }
/**
 * LLama a la funcion para volver al menu principal de la vista
 * @see VistaImagen#volverMenu() 
 */
    void procesaVuelta() {
        vista.volverMenu();
    }
/**
 * Llama a los metodos de la vista y el modelo para restaurar el valor por defecto de la ventana.
 * @see ModeloT#setBrillo(int)
 * @see ModeloT#setContraste(int) 
 * @see ModeloT#setNitidez(int) 
 * @see VistaImagen#restaura()
 */
    void restauracion() {
        modelo.setBrillo(50);
        modelo.setContraste(50);
        modelo.setNitidez(50);
        vista.restaura();
    }
}
