package my.teleVista;

import my.teleModelo.ModeloT;

/**
 * Controlador de la interfaz sencilla de la configuración de sonido de un televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see VistaSonido
 */
public class ControladorS {
    private final VistaSonido vista;
    private final ModeloT modelo;
    /**
     * Constructor del controlador de la configuracion de sonido, se declaran el modelo usado y la vista de la configuracion.
     * 
     * @param v La vista usada en la configuracion de sonido.
     * @param m El modelo de la aplicación.
     */
    public ControladorS(VistaSonido v, ModeloT m){
        vista = v;
        modelo = m;
    }
/**
 * Llama a la función en el modelo para cambiar el valor de seleccion del volumen automatico.
 * @param selected true si se activa, false si se desactiva
 * @see ModeloT#setVolAuto(boolean)
 */
    void setActivado(boolean selected) {
        modelo.setVolAuto(selected);
    }
/**
 * LLama a la funcion para volver al menu principal de la vista
 * @see VistaSonido#volverMenu() 
 */
    void procesaVolver() {
        vista.volverMenu();
    }
/**
 * Llama a la funcion del modelo para cambiar el valor del volumen
 * @param value Un entero: 0 para bajo, 50 para medio, 100 para alto.
 */
    void cambioVolumen(int value) {
        modelo.setVolumen(value);
    }
/**
 * Llama a la funcion de cambio de volumen y volumen automatico para poner los valores por defecto, llama a la funcion de la vista que pone la ventana de nuevo como estaba al principio.
 *@see ModeloT#setVolAuto(boolean) 
 *@see ModeloT#setVolumen(int) 
 *@see VistaSonido#restaura() 
 */
    void restauracion() {
        modelo.setVolumen(50);
        modelo.setVolAuto(false);
        vista.restaura();
    }
}