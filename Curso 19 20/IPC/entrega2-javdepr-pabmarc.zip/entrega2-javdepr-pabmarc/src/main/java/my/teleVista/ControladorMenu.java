package my.teleVista;

import my.teleModelo.ModeloT;

/**
 * Controlador del menu rapido de configuracion de un televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see VistaMenu
 */
class ControladorMenu {
    private final VistaMenu vista;
    private final ModeloT modelo;
     /**
     * Constructor del controlador del menu, se declaran el modelo usado y la vista del menu.
     * 
     * @param v La vista usada para el menu.
     * @param m El modelo de la aplicación.
     */
    ControladorMenu(VistaMenu aThis, ModeloT modelo) {
        vista=aThis;
        this.modelo=modelo;
    }
    /**
     * Llama al metodo de la vista para abrir la pestaña de configuracion de canales.
     * @see VistaMenu#abrirCanales() 
     */
    void procesarCanales() {
        vista.abrirCanales();
    }
     /**
     * Llama al metodo de la vista para abrir la pestaña de configuracion de imagen.
     * @see VistaMenu#abrirImagen() 
     */
    void procesarImagen() {
        vista.abrirImagen();
    }
     /**
     * Llama al metodo de la vista para abrir la pestaña de configuracion de sonido.
     * @see VistaMenu#abrirSonido() 
     */
    void procesarSonido() {
        vista.abrirSonido();
    }
    /**
     * Llama a los metodos de la vista y el modelo para devolver a la aplicación al estado original.
     * @see ModeloT#restauracion()
     * @see VistaMenu#restauracion() 
     */
    void procesaRestaurar() {
        modelo.restauracion();
        vista.restauracion();
    }
}
