package my.television;

import javax.swing.ImageIcon;
/**
 * Representación de un canal donde se guarda el nombre del canal, la ruta del icono del canal y si el canal está activado o no.
 *
 * @author javdepr
 * @author pabmarc
 */
public class Canal {
    private String nombre;
    private final ImageIcon icono;
    private boolean activado;
    /**
     * Constructor del canal, se inicia el canal estando activado.
     * 
     * @param nombre Nombre del canal.
     * @param icono Ruta del icono.
     */
    public Canal(String nombre, String icono ){
       this.nombre=nombre;
       this.icono=new ImageIcon(icono);
       activado=true;
    }
    /**
     * Consulta el nombre del canal.
     * 
     * @return Nombre del canal
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Cambia el nombre del canal.
     * 
     * @param nom El nuevo nombre del canal.
     */
    public void setNombre(String nom){
        nombre=nom;
    }
    /**
     * Consulta el icono del canal.
     * 
     * @return El icono del canal.
     */
    public ImageIcon getIcono(){
        return icono;
    }
    /**
     * Devuelve el estado de activación del canal.
     * 
     * @return True si el canal está activado, False si el canal está desactivado.
     */
    public boolean getActivado(){
        return activado;
    }
    /**
     * Cambia el estado de activación del canal.
     * 
     * @param activacion True para activarlo, False para desactivarlo.
     */
    public void setActivado(boolean activacion){
        activado=activacion;
    }
}
