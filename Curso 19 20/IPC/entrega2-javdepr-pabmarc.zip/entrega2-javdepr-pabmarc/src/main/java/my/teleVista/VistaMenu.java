package my.teleVista;

import my.teleModelo.ModeloT;
import my.television.Main;

/**
 * Vista de la interfaz sencilla del menu rapido de configuracion de un televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see ControladorMenu
 */
public class VistaMenu extends javax.swing.JFrame {
    private final ControladorMenu controlador;
    private final ModeloT modelo;
    /**
     * Inicializador de la vista del menu, donde se declaran el modelo usado y el controlador de la aplicación.Se inicializan los elementos de la interfaz del menu.
     *
     * @param m El modelo
     */
    public VistaMenu(ModeloT m) {
        initComponents();
        modelo=m;
        controlador=new ControladorMenu(this,modelo);
        canal.setText(modelo.getListaCanales().get(modelo.getCanalActual()-1).getNombre());
        switch (modelo.getVolumen()) {
            case 0:
                volumen.setText("Bajo");
                break;
            case 50:
                volumen.setText("Medio");
                break;
            default:
                volumen.setText("Alto");
                break;
        }

        if (modelo.getVolAuto()){
            volumenAuto.setText("Encendido");
        }else{
            volumenAuto.setText("Apagado");
        }
        brillo.setText(String.valueOf(modelo.getBrillo()));
        nitidez.setText(String.valueOf(modelo.getNitidez()));
        contraste.setText(String.valueOf(modelo.getContraste()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        titulo = new javax.swing.JPanel();
        menu = new javax.swing.JLabel();
        contenedor = new javax.swing.JPanel();
        datos = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        canal = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        volumen = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        volumenAuto = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        brillo = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        nitidez = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        contraste = new javax.swing.JLabel();
        imagen = new javax.swing.JButton();
        sonido = new javax.swing.JButton();
        canales = new javax.swing.JButton();
        red = new javax.swing.JButton();
        general = new javax.swing.JButton();
        seguridad = new javax.swing.JButton();
        accesibilidad = new javax.swing.JButton();
        botones = new javax.swing.JPanel();
        restaurar = new javax.swing.JButton();
        salir = new javax.swing.JButton();

        jButton2.setText("Modo oscuro");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(800, 650));
        setMinimumSize(new java.awt.Dimension(800, 650));
        setPreferredSize(new java.awt.Dimension(800, 650));
        setResizable(false);

        titulo.setBackground(java.awt.Color.darkGray);
        titulo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        titulo.setForeground(new java.awt.Color(255, 204, 51));
        titulo.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        titulo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 45, 5));

        menu.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        menu.setForeground(java.awt.Color.orange);
        menu.setText("MENÚ PRINCIPAL");
        titulo.add(menu);

        getContentPane().add(titulo, java.awt.BorderLayout.PAGE_START);

        contenedor.setBackground(java.awt.Color.white);
        contenedor.setLayout(new java.awt.GridLayout(9, 0, 0, 4));

        datos.setBackground(java.awt.Color.darkGray);
        datos.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.darkGray));
        datos.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 15));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(java.awt.Color.orange);
        jLabel2.setText("Canal actual:");
        datos.add(jLabel2);

        canal.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        canal.setForeground(java.awt.Color.white);
        canal.setText("jLabel3");
        datos.add(canal);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(java.awt.Color.orange);
        jLabel4.setText("  Volumen:");
        datos.add(jLabel4);

        volumen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        volumen.setForeground(java.awt.Color.white);
        volumen.setText("jLabel5");
        datos.add(volumen);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(java.awt.Color.orange);
        jLabel12.setText("  Volumen automático:");
        datos.add(jLabel12);

        volumenAuto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        volumenAuto.setForeground(java.awt.Color.white);
        volumenAuto.setText("jLabel13");
        datos.add(volumenAuto);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(java.awt.Color.orange);
        jLabel10.setText("  Brillo:");
        datos.add(jLabel10);

        brillo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        brillo.setForeground(java.awt.Color.white);
        brillo.setText("jLabel7");
        datos.add(brillo);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(java.awt.Color.orange);
        jLabel8.setText("  Nitidez:");
        datos.add(jLabel8);

        nitidez.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nitidez.setForeground(java.awt.Color.white);
        nitidez.setText("jLabel9");
        datos.add(nitidez);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(java.awt.Color.orange);
        jLabel6.setText("  Contraste:");
        datos.add(jLabel6);

        contraste.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        contraste.setForeground(java.awt.Color.white);
        contraste.setText("jLabel11");
        datos.add(contraste);

        contenedor.add(datos);

        imagen.setBackground(java.awt.Color.gray);
        imagen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        imagen.setForeground(java.awt.Color.orange);
        imagen.setText("IMAGEN >");
        imagen.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        imagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imagenActionPerformed(evt);
            }
        });
        contenedor.add(imagen);

        sonido.setBackground(java.awt.Color.gray);
        sonido.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        sonido.setForeground(java.awt.Color.orange);
        sonido.setText("SONIDO >");
        sonido.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sonido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sonidoActionPerformed(evt);
            }
        });
        contenedor.add(sonido);

        canales.setBackground(java.awt.Color.gray);
        canales.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        canales.setForeground(java.awt.Color.orange);
        canales.setText("CANALES >");
        canales.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        canales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                canalesActionPerformed(evt);
            }
        });
        contenedor.add(canales);

        red.setBackground(java.awt.Color.gray);
        red.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        red.setForeground(java.awt.Color.orange);
        red.setText("RED >");
        red.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        contenedor.add(red);

        general.setBackground(java.awt.Color.gray);
        general.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        general.setForeground(java.awt.Color.orange);
        general.setText("GENERAL >");
        general.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        contenedor.add(general);

        seguridad.setBackground(java.awt.Color.gray);
        seguridad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        seguridad.setForeground(java.awt.Color.orange);
        seguridad.setText("SEGURIDAD >");
        seguridad.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        contenedor.add(seguridad);

        accesibilidad.setBackground(java.awt.Color.gray);
        accesibilidad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accesibilidad.setForeground(java.awt.Color.orange);
        accesibilidad.setText("ACCESIBILIDAD >");
        accesibilidad.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        contenedor.add(accesibilidad);

        botones.setBackground(java.awt.Color.darkGray);
        botones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        botones.setMaximumSize(new java.awt.Dimension(100, 100));
        botones.setPreferredSize(new java.awt.Dimension(100, 100));
        botones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 150, 5));

        restaurar.setBackground(java.awt.Color.white);
        restaurar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        restaurar.setText("RESTAURAR VALORES DE FÁBRICA");
        restaurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restaurarActionPerformed(evt);
            }
        });
        botones.add(restaurar);

        salir.setBackground(java.awt.Color.white);
        salir.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        salir.setText("SALIR");
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        botones.add(salir);

        contenedor.add(botones);

        getContentPane().add(contenedor, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void imagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imagenActionPerformed
        controlador.procesarImagen();
    }//GEN-LAST:event_imagenActionPerformed
                
    
    private void canalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_canalesActionPerformed
        controlador.procesarCanales();
    }//GEN-LAST:event_canalesActionPerformed

    private void sonidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sonidoActionPerformed
        controlador.procesarSonido();
    }//GEN-LAST:event_sonidoActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_salirActionPerformed

    private void restaurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restaurarActionPerformed
        controlador.procesaRestaurar();
    }//GEN-LAST:event_restaurarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton accesibilidad;
    private javax.swing.JPanel botones;
    private javax.swing.JLabel brillo;
    private javax.swing.JLabel canal;
    private javax.swing.JButton canales;
    private javax.swing.JPanel contenedor;
    private javax.swing.JLabel contraste;
    private javax.swing.JPanel datos;
    private javax.swing.JButton general;
    private javax.swing.JButton imagen;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel menu;
    private javax.swing.JLabel nitidez;
    private javax.swing.JButton red;
    private javax.swing.JButton restaurar;
    private javax.swing.JButton salir;
    private javax.swing.JButton seguridad;
    private javax.swing.JButton sonido;
    private javax.swing.JPanel titulo;
    private javax.swing.JLabel volumen;
    private javax.swing.JLabel volumenAuto;
    // End of variables declaration//GEN-END:variables
/**
 * Abre la ventana de configuracion de canales.
 * @see StateMachine#mostrarCanales() 
 */
    void abrirCanales() {
        Main.television.mostrarCanales();
    }
/**
 * Abre la ventana de configuración de imagen.
 * @see StateMachine#mostrarImagen() 
 */
    void abrirImagen() {
        Main.television.mostrarImagen();
    }
/**
 * Abre la ventana de configuración de sonido.
 * @see StateMachine#mostrarSonido() 
 */    
    void abrirSonido() {
        Main.television.mostrarSonido();
    }
/**
 * Cambia las etiquetas a los valores por defecto de todas las configuraciones.
 */
    void restauracion() {
        canal.setText("La 1");
        volumen.setText("Medio");
        volumenAuto.setText("Apagado");
        brillo.setText("50");
        nitidez.setText("50");
        contraste.setText("50");
    }
}
