package my.teleVista;

import java.awt.Color;
import javax.swing.DefaultListModel;
import my.teleModelo.ModeloT;
import my.television.Main;
/**
 * Vista de la interfaz sencilla del televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see ControladorC
 * @see my.television.Canal
 */
public class VistaC extends javax.swing.JFrame {
    ControladorC controlador;
    ModeloT modelo;
    DefaultListModel<String> dlm;
    /**
     * Inicializador de la vista de configuracion de canales, donde se declaran el modelo usado y el controlador de la aplicación.Se inicializan los elementos de la interfaz de configuracion de canales.
     *
     * @param m El modelo
     */
    public VistaC(ModeloT m) {
        initComponents();
        modelo = m;
        controlador = new ControladorC(this,modelo);
        icono1.setIcon(modelo.getListaCanales().get(0).getIcono());
        icono2.setIcon(modelo.getListaCanales().get(1).getIcono());
        icono3.setIcon(modelo.getListaCanales().get(2).getIcono());
        icono4.setIcon(modelo.getListaCanales().get(3).getIcono());
        icono5.setIcon(modelo.getListaCanales().get(4).getIcono());
        icono6.setIcon(modelo.getListaCanales().get(5).getIcono());
        nombre1.setText(modelo.getListaCanales().get(0).getNombre());
        nombre2.setText(modelo.getListaCanales().get(1).getNombre());
        nombre3.setText(modelo.getListaCanales().get(2).getNombre());
        nombre4.setText(modelo.getListaCanales().get(3).getNombre());
        nombre5.setText(modelo.getListaCanales().get(4).getNombre());
        nombre6.setText(modelo.getListaCanales().get(5).getNombre());
        viendo.setIcon(modelo.getListaCanales().get(modelo.getCanalActual()-1).getIcono());
        dlm= new DefaultListModel<>();
        listaFav.setModel(dlm);
        if(!modelo.getCanalesFav().isEmpty()){
            for(int i=0; i<modelo.getCanalesFav().size();i++){
                dlm.addElement(modelo.getCanalesFav().get(i));
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        botones = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        volver = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        ordenar = new javax.swing.JButton();
        favoritos = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        contenedor = new javax.swing.JPanel();
        pantalla = new javax.swing.JPanel();
        viendo = new javax.swing.JLabel();
        canales = new javax.swing.JPanel();
        icono1 = new javax.swing.JLabel();
        nombre1 = new javax.swing.JTextField();
        icono2 = new javax.swing.JLabel();
        nombre2 = new javax.swing.JTextField();
        icono3 = new javax.swing.JLabel();
        nombre3 = new javax.swing.JTextField();
        icono4 = new javax.swing.JLabel();
        nombre4 = new javax.swing.JTextField();
        icono5 = new javax.swing.JLabel();
        nombre5 = new javax.swing.JTextField();
        icono6 = new javax.swing.JLabel();
        nombre6 = new javax.swing.JTextField();
        edicion = new javax.swing.JPanel();
        edita = new javax.swing.JPanel();
        canal = new javax.swing.JLabel();
        activacion = new javax.swing.JCheckBox();
        nombre = new javax.swing.JLabel();
        nombreCanal = new javax.swing.JTextField();
        restaura = new javax.swing.JButton();
        favs = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaFav = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        borrar = new javax.swing.JButton();
        borrarTodo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(800, 600));
        setMinimumSize(new java.awt.Dimension(800, 600));
        setPreferredSize(new java.awt.Dimension(800, 600));
        setResizable(false);

        botones.setBackground(java.awt.Color.gray);
        botones.setMinimumSize(new java.awt.Dimension(462, 80));
        botones.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(java.awt.Color.gray);

        volver.setBackground(new java.awt.Color(204, 204, 204));
        volver.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        volver.setText("<VOLVER");
        volver.setMaximumSize(new java.awt.Dimension(71, 50));
        volver.setMinimumSize(new java.awt.Dimension(71, 50));
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });
        jPanel2.add(volver);

        botones.add(jPanel2, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(java.awt.Color.gray);
        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 40, 15));

        ordenar.setBackground(java.awt.Color.white);
        ordenar.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        ordenar.setText("Ordenar");
        buttonGroup1.add(ordenar);
        ordenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ordenarActionPerformed(evt);
            }
        });
        jPanel3.add(ordenar);

        favoritos.setBackground(java.awt.Color.white);
        favoritos.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        favoritos.setText("Favoritos");
        buttonGroup1.add(favoritos);
        favoritos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                favoritosActionPerformed(evt);
            }
        });
        jPanel3.add(favoritos);

        editar.setBackground(java.awt.Color.white);
        editar.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        editar.setText("Editar");
        buttonGroup1.add(editar);
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });
        jPanel3.add(editar);

        botones.add(jPanel3, java.awt.BorderLayout.LINE_END);

        getContentPane().add(botones, java.awt.BorderLayout.PAGE_START);

        contenedor.setLayout(new java.awt.GridLayout(2, 2));

        pantalla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red));
        pantalla.setForeground(java.awt.Color.white);
        pantalla.setToolTipText("");
        pantalla.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 100));
        pantalla.add(viendo);

        contenedor.add(pantalla);

        canales.setBackground(java.awt.Color.white);
        canales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        canales.setLayout(new java.awt.GridLayout(6, 2));

        icono1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono1MouseClicked(evt);
            }
        });
        canales.add(icono1);

        nombre1.setEditable(false);
        nombre1.setBackground(java.awt.Color.white);
        nombre1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre1.setText("La 1");
        nombre1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre1MouseClicked(evt);
            }
        });
        nombre1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre1ActionPerformed(evt);
            }
        });
        canales.add(nombre1);

        icono2.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono2MouseClicked(evt);
            }
        });
        canales.add(icono2);

        nombre2.setEditable(false);
        nombre2.setBackground(java.awt.Color.white);
        nombre2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre2.setText("La 2");
        nombre2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre2MouseClicked(evt);
            }
        });
        nombre2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre2ActionPerformed(evt);
            }
        });
        canales.add(nombre2);

        icono3.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono3MouseClicked(evt);
            }
        });
        canales.add(icono3);

        nombre3.setEditable(false);
        nombre3.setBackground(java.awt.Color.white);
        nombre3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre3.setText("Antena 3");
        nombre3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre3MouseClicked(evt);
            }
        });
        canales.add(nombre3);

        icono4.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono4MouseClicked(evt);
            }
        });
        canales.add(icono4);

        nombre4.setEditable(false);
        nombre4.setBackground(java.awt.Color.white);
        nombre4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre4.setText("Cuatro");
        nombre4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre4MouseClicked(evt);
            }
        });
        canales.add(nombre4);

        icono5.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono5MouseClicked(evt);
            }
        });
        canales.add(icono5);

        nombre5.setEditable(false);
        nombre5.setBackground(java.awt.Color.white);
        nombre5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre5.setText("Telecinco");
        nombre5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre5MouseClicked(evt);
            }
        });
        canales.add(nombre5);

        icono6.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        icono6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icono6MouseClicked(evt);
            }
        });
        canales.add(icono6);

        nombre6.setEditable(false);
        nombre6.setBackground(java.awt.Color.white);
        nombre6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nombre6.setText("La Sexta");
        nombre6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nombre6MouseClicked(evt);
            }
        });
        nombre6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre6ActionPerformed(evt);
            }
        });
        canales.add(nombre6);

        contenedor.add(canales);

        edicion.setBackground(java.awt.Color.lightGray);
        edicion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        edicion.setLayout(new java.awt.BorderLayout());

        edita.setBackground(java.awt.Color.lightGray);
        edita.setLayout(new java.awt.GridLayout(3, 2, 0, 50));

        canal.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        canal.setText("  Canal 1");
        edita.add(canal);

        activacion.setBackground(java.awt.Color.lightGray);
        activacion.setSelected(true);
        activacion.setText("Activado");
        activacion.setEnabled(false);
        activacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                activacionActionPerformed(evt);
            }
        });
        edita.add(activacion);

        nombre.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        nombre.setText("  Nombre del canal");
        edita.add(nombre);

        nombreCanal.setEditable(false);
        nombreCanal.setBackground(java.awt.Color.white);
        nombreCanal.setText("La 1");
        nombreCanal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nombreCanalKeyPressed(evt);
            }
        });
        edita.add(nombreCanal);
        nombreCanal.getAccessibleContext().setAccessibleName("nombreCanal");

        edicion.add(edita, java.awt.BorderLayout.CENTER);

        restaura.setBackground(java.awt.Color.white);
        restaura.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        restaura.setText("RESTAURAR TODO");
        restaura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restauraActionPerformed(evt);
            }
        });
        edicion.add(restaura, java.awt.BorderLayout.PAGE_END);

        contenedor.add(edicion);

        favs.setBackground(java.awt.Color.lightGray);
        favs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        favs.setLayout(new java.awt.GridLayout(3, 1, 5, 0));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel10.setText("   Favoritos");
        favs.add(jLabel10);

        listaFav.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(listaFav);

        favs.add(jScrollPane1);

        jPanel1.setBackground(java.awt.Color.lightGray);

        borrar.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        borrar.setText("Borrar");
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });
        jPanel1.add(borrar);

        borrarTodo.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        borrarTodo.setText("Borrar Todo");
        borrarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarTodoActionPerformed(evt);
            }
        });
        jPanel1.add(borrarTodo);

        favs.add(jPanel1);

        contenedor.add(favs);

        getContentPane().add(contenedor, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombre6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre6ActionPerformed

    private void nombre1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre1MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(0).getActivado()){
                    controlador.setCanal(0);
                }
                break;
            case 1:
                controlador.cambiaOrden(0);
                break;
            case 2:
                controlador.addFavoritos(0);
                break;
            case 3:
                controlador.setEditado(0);
                break;
        }
    }//GEN-LAST:event_nombre1MouseClicked

    private void nombre2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre2MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(1).getActivado()){
                    controlador.setCanal(1);
                }
                break;
            case 1:
                controlador.cambiaOrden(1);
                break;
            case 2:
                controlador.addFavoritos(1);
                break;
            case 3:
                controlador.setEditado(1);
                break;
        }
    }//GEN-LAST:event_nombre2MouseClicked

    private void nombre3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre3MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(2).getActivado()){
                    controlador.setCanal(2);
                }
                break;
            case 1:
                controlador.cambiaOrden(2);
                break;
            case 2:
                controlador.addFavoritos(2);
                break;
            case 3:
                controlador.setEditado(2);
                break;
        }
    }//GEN-LAST:event_nombre3MouseClicked

    private void nombre4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre4MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(3).getActivado()){
                    controlador.setCanal(3);
                }
                break;
            case 1:
                controlador.cambiaOrden(3);
                break;
            case 2:
                controlador.addFavoritos(3);
                break;
            case 3:
                controlador.setEditado(3);
                break;
        }
    }//GEN-LAST:event_nombre4MouseClicked

    private void nombre5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre5MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(4).getActivado()){
                    controlador.setCanal(4);
                }
                break;
            case 1:
                controlador.cambiaOrden(4);
                break;
            case 2:
                controlador.addFavoritos(4);
                break;
            case 3:
                controlador.setEditado(4);
                break;
        }
    }//GEN-LAST:event_nombre5MouseClicked

    private void nombre6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombre6MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(5).getActivado()){
                    controlador.setCanal(5);
                }
                break;
            case 1:
                controlador.cambiaOrden(5);
                break;
            case 2:
                controlador.addFavoritos(5);
                break;
            case 3:
                controlador.setEditado(5);
                break;
        }
    }//GEN-LAST:event_nombre6MouseClicked

    private void ordenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ordenarActionPerformed
        if(modelo.getEstado()!=1){
            controlador.setEstado(1);  
        }else{
            controlador.setEstado(0);
        }
        activacion.setEnabled(false);
        nombreCanal.setEditable(false);
    }//GEN-LAST:event_ordenarActionPerformed

    private void favoritosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_favoritosActionPerformed
        if(modelo.getEstado()!=2){
            controlador.setEstado(2);  
        }else{
            controlador.setEstado(0);
        }
        activacion.setEnabled(false);
        nombreCanal.setEditable(false);
    }//GEN-LAST:event_favoritosActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        if(modelo.getEstado()!=3){
            controlador.setEstado(3);
            activacion.setEnabled(true);
            nombreCanal.setEditable(true);
        }else{
            controlador.setEstado(0);
            activacion.setEnabled(false);
            nombreCanal.setEditable(false);
        }
    }//GEN-LAST:event_editarActionPerformed

    private void icono1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono1MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(0).getActivado()){
                    controlador.setCanal(0);
                }
                break;
            case 1:
                controlador.cambiaOrden(0);
                break;
            case 2:
                controlador.addFavoritos(0);
                break;
            case 3:
                controlador.setEditado(0);
                break;
        }
    }//GEN-LAST:event_icono1MouseClicked

    private void icono2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono2MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(1).getActivado()){
                    controlador.setCanal(1);
                }
                break;
            case 1:
                controlador.cambiaOrden(1);
                break;
            case 2:
                controlador.addFavoritos(1);
                break;
            case 3:
                controlador.setEditado(1);
                break;
        }
    }//GEN-LAST:event_icono2MouseClicked

    private void icono3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono3MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(2).getActivado()){
                    controlador.setCanal(2);
                }
                break;
            case 1:
                controlador.cambiaOrden(2);
                break;
            case 2:
                controlador.addFavoritos(2);
                break;
            case 3:
                controlador.setEditado(2);
                break;
        }
    }//GEN-LAST:event_icono3MouseClicked

    private void icono4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono4MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(3).getActivado()){
                    controlador.setCanal(3);
                }
                break;
            case 1:
                controlador.cambiaOrden(3);
                break;
            case 2:
                controlador.addFavoritos(3);
                break;
            case 3:
                controlador.setEditado(3);
                break;
        }
    }//GEN-LAST:event_icono4MouseClicked

    private void icono5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono5MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(4).getActivado()){
                    controlador.setCanal(4);
                }
                break;
            case 1:
                controlador.cambiaOrden(4);
                break;
            case 2:
                controlador.addFavoritos(4);
                break;
            case 3:
                controlador.setEditado(4);
                break;
        }
    }//GEN-LAST:event_icono5MouseClicked

    private void icono6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icono6MouseClicked
        switch (modelo.getEstado()) {
            case 0:
                if (modelo.getListaCanales().get(5).getActivado()){
                    controlador.setCanal(5);
                }
                break;
            case 1:
                controlador.cambiaOrden(5);
                break;
            case 2:
                controlador.addFavoritos(5);
                break;
            case 3:
                controlador.setEditado(5);
                break;
        }
    }//GEN-LAST:event_icono6MouseClicked

    private void activacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_activacionActionPerformed
        controlador.setActivado(activacion.isSelected());
    }//GEN-LAST:event_activacionActionPerformed

    private void nombreCanalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreCanalKeyPressed
        if(evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER){
            if((!"".equals(nombreCanal.getText())) && (controlador.nombreUsado(nombreCanal.getText()) == false)){
                controlador.setNombre(nombreCanal.getText());             
            }
        } 
    }//GEN-LAST:event_nombreCanalKeyPressed

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
        int num=listaFav.getSelectedIndex();
        if(num!=-1 && modelo.getEstado()==2){
            controlador.procesaBorra(num);
        }
    }//GEN-LAST:event_borrarActionPerformed

    private void borrarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarTodoActionPerformed
        if(modelo.getEstado()==2){
            controlador.borraTodo();
        }
    }//GEN-LAST:event_borrarTodoActionPerformed

    private void nombre1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre1ActionPerformed

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        controlador.procesaVuelta();
    }//GEN-LAST:event_volverActionPerformed

    private void nombre2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre2ActionPerformed

    private void restauraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restauraActionPerformed
        if(modelo.getEstado()==3){
            controlador.restauracion();     
        }
    }//GEN-LAST:event_restauraActionPerformed
    /**
     * Pone en la zona de visionado el canal que se quiere visualizar.
     * 
     * @param num Posicion del canal en la lista de canales.
     * 
     * @see ModeloT#getListaCanales()
     * @see my.television.Canal#getIcono() 
     */
    public void setCanal(int num){
        viendo.setIcon(modelo.getListaCanales().get(num).getIcono());
    }
    /**
     * Actualiza el panel de edición de canales y coloca en el canal el número del canal, en el botón de
     * activación el estado del canal (Activado/Desactivado) y el nombre guardado del canal.
     * 
     * @param num Posicion del canal en la lista de canales.
     * 
     * @see ModeloT#getListaCanales()
     * @see my.television.Canal#getNombre()
     * @see my.television.Canal#getActivado()
     */
    public void setCanalEdit(int num){
        canal.setText("  Canal "+ (num+1));
        activacion.setSelected(modelo.getListaCanales().get(num).getActivado());
        nombreCanal.setText(modelo.getListaCanales().get(num).getNombre());
    }
    /**
     * Cambia los colores de los botones señalando cuando un botón está seleccionado dependiendo del estado de la aplicacion.
     * 
     * @param num Estado en el que se encuentra la aplicación: 0=Visionado 1=Ordenar 2=Favoritos 3=Editar 
     */
    public void eligeBoton(int num){
        switch (num) {
            case 0:
                ordenar.setBackground(Color.white);
                favoritos.setBackground(Color.white);
                editar.setBackground(Color.white);
                pantalla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red));
                canales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                edicion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                favs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                break;
            case 1:
                ordenar.setBackground(Color.orange);
                favoritos.setBackground(Color.white);
                editar.setBackground(Color.white);
                pantalla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
                canales.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red,2));
                edicion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                favs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                break;
            case 2:
                ordenar.setBackground(Color.white);
                favoritos.setBackground(Color.orange);
                editar.setBackground(Color.white);
                pantalla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
                canales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204,204,204)));
                edicion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                favs.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red,2));
                break;
            case 3:
                ordenar.setBackground(Color.white);
                favoritos.setBackground(Color.white);
                editar.setBackground(Color.orange);
                pantalla.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
                canales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                edicion.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.red,2));
                favs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
                break;
        }
    }
    /**
     * Mientras está la aplicación en estado ORDENAR, cuando se elige un canal se señala de rojo para indicar la selección.
     * @param num Canal seleccionado
     */
    public void senalCanal(int num){
        switch (num) {
            case 0:
                nombre1.setBackground(Color.red);
                break;
            case 1:
                nombre2.setBackground(Color.red);
                break;
            case 2:
                nombre3.setBackground(Color.red);
                break;
            case 3:
                nombre4.setBackground(Color.red);
                break;     
            case 4:
                nombre5.setBackground(Color.red);
                break;
            case 5:
                nombre6.setBackground(Color.red);
                break;
        }
    }
    /**
     * Actualiza la lista de canales en la interfaz, poniendo los iconos y los nombres de los canales en el orden adecuado.
     * 
     * @see ModeloT#getListaCanales() 
     * @see my.television.Canal#getIcono()
     * @see my.television.Canal#getNombre()
     */
    public void actualizaCanales(){
        icono1.setIcon(modelo.getListaCanales().get(0).getIcono());
        icono2.setIcon(modelo.getListaCanales().get(1).getIcono());
        icono3.setIcon(modelo.getListaCanales().get(2).getIcono());
        icono4.setIcon(modelo.getListaCanales().get(3).getIcono());
        icono5.setIcon(modelo.getListaCanales().get(4).getIcono());
        icono6.setIcon(modelo.getListaCanales().get(5).getIcono());
        nombre1.setText(modelo.getListaCanales().get(0).getNombre());
        nombre2.setText(modelo.getListaCanales().get(1).getNombre());
        nombre3.setText(modelo.getListaCanales().get(2).getNombre());
        nombre4.setText(modelo.getListaCanales().get(3).getNombre());
        nombre5.setText(modelo.getListaCanales().get(4).getNombre());
        nombre6.setText(modelo.getListaCanales().get(5).getNombre());
    }
    /**
     * Cuando la interfaz está en estado ORDENAR, una vez cambiado el estado o se ha realizado ya el cambio de orden, restaura el color de las etiquetas.
     */
    public void restaura(){
        if(nombre1.getBackground()==Color.red){
            nombre1.setBackground(Color.white);
        }if(nombre2.getBackground()==Color.red){
            nombre2.setBackground(Color.white);
        }if(nombre3.getBackground()==Color.red){
            nombre3.setBackground(Color.white);
        }if(nombre4.getBackground()==Color.red){
            nombre4.setBackground(Color.white);
        }if(nombre5.getBackground()==Color.red){
            nombre5.setBackground(Color.white);
        }if(nombre6.getBackground()==Color.red){
            nombre6.setBackground(Color.white);
        }
    }
    /**
     * En estado FAVORITOS, si la lista de favoritos no contiene el canal, añade el nombre del canal a la lista de la interfaz.
     * 
     * @param num Posicion del canal en la lista de canales.
     * 
     * @see ModeloT#getListaCanales() 
     * @see my.television.Canal#getNombre()
     */
    public void addCanalFav(int num){
        if(!dlm.contains(modelo.getListaCanales().get(num).getNombre())){
            dlm.addElement(modelo.getListaCanales().get(num).getNombre());
        }
    }
    /**
     * En estado FAVORITOS, elimina el canal seleccionado en la lista.
     * 
     * @param num Posición del nombre canal en la lista de la interfaz.
     */
    public void deleteCanalFav(int num){
        dlm.remove(num);
    }
    /**
     * En estado FAVORITOS, elimina todos los nombres de canales de la lista.
     */
    public void clearListaFav(){
        dlm.clear();
    }
    /**
     * Actualiza el nombre de un canal tanto en el panel de canales como en la lista de favoritos si estuviera.
     * @param nombre El nuevo nombre que se va a poner
     */
    public void setNombre(String nombre){
        switch (modelo.getCanalEdit()){
            case 0:
                nombre1.setText(nombre);
                break;
            case 1:
                nombre2.setText(nombre);
                break;
            case 2:
                nombre3.setText(nombre);
                break;
            case 3:
                nombre4.setText(nombre);
                break;
            case 4:
                nombre5.setText(nombre);
                break;
            case 5:
                nombre6.setText(nombre);
                break;
        }
        String old_name;
        old_name = modelo.getListaCanales().get(modelo.getCanalEdit()).getNombre();
        if(dlm.contains(old_name)){
            int num=dlm.indexOf(old_name);
            dlm.set(num, nombre);
        }
    }
    /**
     * Regresa al menú principal
     * @see my.teleVista.StateMachine
     */
    void volverMenu() {
        Main.television.mostrarMenu();
    }
    /**
     * Vuelve al estado original de la pantalla de canales. Borrando la lista de canales favoritos, restaurando los nombres y orden de los canales y colocando La 1 como canal en vision.
     * @see ModeloT#getListaCanales() 
     * @see my.television.Canal#getNombre() 
     * @see my.television.Canal#getIcono() 
     */
    void restauraTodo() {
        this.actualizaCanales();
        dlm.clear();
        nombreCanal.setText(modelo.getListaCanales().get(0).getNombre());
        canal.setText("Canal 1");
        viendo.setIcon(modelo.getListaCanales().get(0).getIcono());
        this.eligeBoton(0);
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox activacion;
    private javax.swing.JButton borrar;
    private javax.swing.JButton borrarTodo;
    private javax.swing.JPanel botones;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel canal;
    private javax.swing.JPanel canales;
    private javax.swing.JPanel contenedor;
    private javax.swing.JPanel edicion;
    private javax.swing.JPanel edita;
    private javax.swing.JButton editar;
    private javax.swing.JButton favoritos;
    private javax.swing.JPanel favs;
    private javax.swing.JLabel icono1;
    private javax.swing.JLabel icono2;
    private javax.swing.JLabel icono3;
    private javax.swing.JLabel icono4;
    private javax.swing.JLabel icono5;
    private javax.swing.JLabel icono6;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listaFav;
    private javax.swing.JLabel nombre;
    private javax.swing.JTextField nombre1;
    private javax.swing.JTextField nombre2;
    private javax.swing.JTextField nombre3;
    private javax.swing.JTextField nombre4;
    private javax.swing.JTextField nombre5;
    private javax.swing.JTextField nombre6;
    private javax.swing.JTextField nombreCanal;
    private javax.swing.JButton ordenar;
    private javax.swing.JPanel pantalla;
    private javax.swing.JButton restaura;
    private javax.swing.JLabel viendo;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables




}
