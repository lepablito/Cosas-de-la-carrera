package my.teleModelo;

import java.util.ArrayList;
import my.television.Canal;
/**
 * Modelo del menu de configuracion del televisor.
 * @author javdepr
 * @author pabmarc
 */
public class ModeloT {
    private final ArrayList<Canal> listaCanales;
    private final ArrayList<String>canalesFav;
    private final ArrayList<Integer> configImagen;
    private boolean configVolAuto;
    private int configVolumen;
    private int estado;
    private int canalActual;
    private int canalEdit;
    /**
     * Constructor del modelo donde se inicializa la lista de canales con todos los canales, el estado de la aplicación (0=VER), canal actual en la zona de visionado y canal en edición. También inicializa los valores por defecto de la configuracion de imagen (Contraste, Nitidez y Brillo) y de volumen (Volumen Automatico y Aumento de Volumen).
     */
    public ModeloT(){
        listaCanales=new ArrayList<>();
        canalesFav=new ArrayList<>();
        listaCanales.add(new Canal("La 1", "src/main/java/my/teleVista/la1.png"));
        listaCanales.add(new Canal("La 2", "src/main/java/my/teleVista/la2.png"));
        listaCanales.add(new Canal("Antena 3", "src/main/java/my/teleVista/antena3.png"));
        listaCanales.add(new Canal("Cuatro", "src/main/java/my/teleVista/cuatro.png"));
        listaCanales.add(new Canal("Telecinco", "src/main/java/my/teleVista/telecinco.png"));
        listaCanales.add(new Canal("La Sexta", "src/main/java/my/teleVista/lasexta.png"));
        estado=0;
        canalActual=1;
        canalEdit=0;
        configImagen = new ArrayList<>();
        configImagen.add(50);
        configImagen.add(50);
        configImagen.add(50);
        configVolAuto = false;
        configVolumen = 50;
    }
    /**
     * Consulta el estado de la aplicación.
     * 
     * @return El estado de la aplicación: 0=VER 1=ORDENAR 2=FAVORITOS 3=EDITAR
     */
    public int getEstado(){
        return estado;
    }
    /**
     * Consulta el canal en la zona de visonado.
     * 
     * @return El canal que aparece actualmente en la zona de visionado.
     */
    public int getCanalActual(){
        return canalActual;
    }
    /**
     * Consulta el canal en la zona de edición.
     * 
     * @return El canal que está en edición. 
     */
    public int getCanalEdit(){
        return canalEdit;
    }
    /**
     * Consulta la lista de canales.
     * 
     * @return La lista de canales.
     */
    public ArrayList<Canal>getListaCanales(){
        return listaCanales;
    }
    /**
     * Consulta la lista de canales favoritos.
     * 
     * @return La lista de canales favoritos.
     */
    public ArrayList<String>getCanalesFav(){
        return canalesFav;
    }
    /**
     * Cambia el estado de la aplicación.
     * 
     * @param estado Estado de la aplicación: 0=VER 1=ORDENAR 2=FAVORITOS 3=EDITAR.
     */
    public void setEstado(int estado){
        this.estado=estado;
    }
    /**
     * Cambia el canal que se está viendo en la zona de visionado.
     * 
     * @param canalActual Posición del canal que se está visionando en la lista de canales.
     */
    public void setCanalActual(int canalActual){
        this.canalActual=canalActual;
    }
    /**
     * Cambia el canal que se está editando.
     * 
     * @param canalEdit Posición del canal que se está editando en la lista de canales.
     */
    public void setCanalEdit(int canalEdit){
        this.canalEdit=canalEdit;
    }
    /**
     * Añade el nombre de un canal a la lista de favoritos.
     * 
     * @param num_canal Posición del canal en la lista de canales.
     * 
     * @see my.television.Canal#getNombre() 
     */
    public void addCanalFav(int num_canal){
        canalesFav.add(listaCanales.get(num_canal).getNombre());
    }
    /**
     * Elimina el nombre de un canal de la lista de favoritos.
     * 
     * @param num_canal Posicón del nombre del canal en la lista de favoritos.
     */
    public void deleteCanalFav(int num_canal){
        canalesFav.remove(num_canal);
    }
    /**
     * Cambia el orden de dos canales en la lista de canales.
     * 
     * @param canal1 Primer canal a cambiar.
     * @param canal2 Segundo canal a cambiar.
     */
    public void setOrden(Canal canal1, Canal canal2){
        int posicion1 = listaCanales.indexOf(canal1);
        int posicion2 = listaCanales.indexOf(canal2);
        listaCanales.set(posicion1, canal2);
        listaCanales.set(posicion2, canal1);
    }
    /**
     * Cambia el estado de activación de un canal.
     * 
     * @param activ True si se activa, False si se desactiva.
     * @param num Posición del canal en la lista de canales.
     * 
     * @see my.television.Canal#setActivado(boolean) 
     */
    public void activarCanal(boolean activ,int num){
        listaCanales.get(num).setActivado(activ);
    }
    /**
     * Cambia el nombre de un canal en la lista de canales.
     * 
     * @param name El nuevo nombre que se va a poner.
     * 
     * @see my.television.Canal#getNombre() 
     * @see my.television.Canal#setNombre(java.lang.String) 
     */
    public void setName(String name){
        int index;
        String old_name = listaCanales.get(canalEdit).getNombre();
        listaCanales.get(canalEdit).setNombre(name);
        index = canalesFav.indexOf(old_name);
        if (index != -1){
            canalesFav.set(index, name);
        }
    }
    /**
     * Limpia la lista entera de favoritos.
     */
    public void clearListaFav(){
        canalesFav.clear();
    }
    /**
     * Consulta el valor del contraste.
     * @return El valor entero del contraste (0-100).
     */
    public int getContraste(){
        return configImagen.get(0);
    }
    /**
     * Consulta el valor del brillo.
     * @return El valor entero del brillo (0-100).
     */
    public int getBrillo(){
        return configImagen.get(1);
    }
    /**
     * Consulta el valor de la nitidez.
     * @return El valor entero de la nitidez (0-100).
     */
    public int getNitidez(){
        return configImagen.get(2);
    }
    /**
     * Consulta el valor del Volumen Automatico.
     * @return false si esta desactivado, true si esta activado.
     */
    public boolean getVolAuto(){
        return configVolAuto;
    }
    /**
     * Consulta el valor del volumen
     * @return 0 si el volumen es Bajo, 50 si el volumen es Medio, 100 si el volumen es Alto.
     */
    public int getVolumen(){
        return configVolumen;
    }
    /**
     * Cambia el valor del contraste.
     * @param valor El valor entero que se quiere poner (0-100)
     */
    public void setContraste(int valor){
        configImagen.set(0, valor);
    }
    /**
     * Cambia el valor del brillo.
     * @param valor El valor entero que se quiere poner (0-100)
     */
    public void setBrillo(int valor){
        configImagen.set(1, valor);
    }
        /**
     * Cambia el valor de la nitidez.
     * @param valor El valor entero que se quiere poner (0-100)
     */
    public void setNitidez(int valor){
        configImagen.set(2, valor);
    }
        /**
     * Cambia el valor del Volumen Automatico.
     * @param valor El valor que se quiere poner (true o false).
     */
    public void setVolAuto(boolean valor){
        configVolAuto=valor;
    }
    /**
     * Cambia el valor del volumen
     * @param valor Un valor entero: 0 para bajo, 50 para medio, 100 para alto.
     */
    public void setVolumen(int valor){
        configVolumen=valor;
    }
    /**
     * Pone todos los valores de la configuración (canales, volumen e imagen) a los que venían por defecto.
     * 
     */
    public void restauracion(){
        listaCanales.clear();
        canalesFav.clear();
        listaCanales.add(new Canal("La 1", "src/main/java/my/teleVista/la1.png"));
        listaCanales.add(new Canal("La 2", "src/main/java/my/teleVista/la2.png"));
        listaCanales.add(new Canal("Antena 3", "src/main/java/my/teleVista/antena3.png"));
        listaCanales.add(new Canal("Cuatro", "src/main/java/my/teleVista/cuatro.png"));
        listaCanales.add(new Canal("Telecinco", "src/main/java/my/teleVista/telecinco.png"));
        listaCanales.add(new Canal("La Sexta", "src/main/java/my/teleVista/lasexta.png"));
        estado=0;
        canalActual=1;
        canalEdit=0;
        configImagen.set(0, 50);
        configImagen.set(1, 50);
        configImagen.set(2, 50);
        configVolAuto=false;
        configVolumen=50;
    }
    /**
    * Restaura el estado del menú de canales a su estado original al abrir la aplicación.
    */
    public void restauraCanal() {
        listaCanales.clear();
        canalesFav.clear();
        estado=0;
        canalActual=1;
        canalEdit=0;
        listaCanales.add(new Canal("La 1", "src/main/java/my/teleVista/la1.png"));
        listaCanales.add(new Canal("La 2", "src/main/java/my/teleVista/la2.png"));
        listaCanales.add(new Canal("Antena 3", "src/main/java/my/teleVista/antena3.png"));
        listaCanales.add(new Canal("Cuatro", "src/main/java/my/teleVista/cuatro.png"));
        listaCanales.add(new Canal("Telecinco", "src/main/java/my/teleVista/telecinco.png"));
        listaCanales.add(new Canal("La Sexta", "src/main/java/my/teleVista/lasexta.png"));
    }
}
