package my.teleVista;

import java.util.Hashtable;
import javax.swing.JLabel;
import my.teleModelo.ModeloT;
import my.television.Main;

/**
 * Vista de la interfaz sencilla de la configuracion de sonido de un televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see ControladorS
 */
public class VistaSonido extends javax.swing.JFrame {
    private final ControladorS controlador;
    private final ModeloT modelo;
    /**
     * Inicializador de la vista de configuracion de sonido, donde se declaran el modelo usado y el controlador de la aplicación.Se inicializan los elementos de la interfaz de configuracion de sonido.
     *
     * @param m El modelo
     */
    public VistaSonido(ModeloT m) {
        initComponents();
        modelo=m;
        controlador= new ControladorS(this,modelo);
        checkVolAuto.setSelected(modelo.getVolAuto());
        sliderVol.setValue(modelo.getVolumen());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        general = new javax.swing.JPanel();
        opciones = new javax.swing.JPanel();
        textoVolAuto = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextArea1 = new javax.swing.JTextArea();
        volAuto = new javax.swing.JPanel();
        checkVolAuto = new javax.swing.JCheckBox();
        textoVolumen = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jTextArea2 = new javax.swing.JTextArea();
        volumen = new javax.swing.JPanel();
        sliderVol = new javax.swing.JSlider();
        botones = new javax.swing.JPanel();
        volver = new javax.swing.JButton();
        restaurar = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(java.awt.Color.white);
        setMaximumSize(new java.awt.Dimension(800, 400));
        setMinimumSize(new java.awt.Dimension(800, 400));
        setPreferredSize(new java.awt.Dimension(800, 400));
        setResizable(false);

        general.setBackground(java.awt.Color.darkGray);
        general.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        general.setLayout(new java.awt.BorderLayout());

        opciones.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.white));
        opciones.setLayout(new java.awt.GridLayout(2, 2));

        textoVolAuto.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.white));
        textoVolAuto.setLayout(new javax.swing.BoxLayout(textoVolAuto, javax.swing.BoxLayout.PAGE_AXIS));

        jTextField1.setEditable(false);
        jTextField1.setBackground(java.awt.Color.gray);
        jTextField1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField1.setForeground(java.awt.Color.orange);
        jTextField1.setText("  Volumen automático");
        jTextField1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        textoVolAuto.add(jTextField1);

        jTextArea1.setBackground(java.awt.Color.lightGray);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("  Establézcalo en Encendido. \n  De esta forma se ajusta el volumen automáticamente para cada \n  cadena de televisión, de manera que pueda escuchar siempre el \n  audio de los canales al volumen que desee, incluso después \n  de cambiar el canal.");
        textoVolAuto.add(jTextArea1);

        opciones.add(textoVolAuto);

        volAuto.setBackground(java.awt.Color.white);
        volAuto.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.lightGray));
        volAuto.setPreferredSize(new java.awt.Dimension(200, 23));
        volAuto.setLayout(new java.awt.BorderLayout());

        checkVolAuto.setBackground(java.awt.Color.white);
        checkVolAuto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        checkVolAuto.setText("Encendido");
        checkVolAuto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        checkVolAuto.setPreferredSize(new java.awt.Dimension(200, 75));
        checkVolAuto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkVolAutoActionPerformed(evt);
            }
        });
        volAuto.add(checkVolAuto, java.awt.BorderLayout.CENTER);

        opciones.add(volAuto);

        textoVolumen.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.white));
        textoVolumen.setLayout(new javax.swing.BoxLayout(textoVolumen, javax.swing.BoxLayout.PAGE_AXIS));

        jTextField2.setEditable(false);
        jTextField2.setBackground(java.awt.Color.gray);
        jTextField2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextField2.setForeground(java.awt.Color.orange);
        jTextField2.setText("  Cantidad de aumento del volumen");
        jTextField2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        textoVolumen.add(jTextField2);

        jTextArea2.setEditable(false);
        jTextArea2.setBackground(java.awt.Color.lightGray);
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea2.setRows(5);
        jTextArea2.setText("  Seleccione Bajo/Media/Alto para ajustar el rango del volumen. \n  Un valor más alto aumenta el volumen.");
        jTextArea2.setBorder(null);
        textoVolumen.add(jTextArea2);

        opciones.add(textoVolumen);

        volumen.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.lightGray));
        volumen.setLayout(new java.awt.BorderLayout());

        sliderVol.setBackground(java.awt.Color.white);
        sliderVol.setMajorTickSpacing(50);
        sliderVol.setPaintLabels(true);
        sliderVol.setPaintTicks(true);
        sliderVol.setSnapToTicks(true);
        sliderVol.setMinimumSize(new java.awt.Dimension(36, 60));
        sliderVol.setPreferredSize(new java.awt.Dimension(200, 100));
        Hashtable<Integer, JLabel> volume = new Hashtable<>();          volume.put(0, new JLabel("Bajo"));          volume.put(50, new JLabel("Media"));          volume.put(100, new JLabel("Alto"));          sliderVol.setLabelTable(volume);
        sliderVol.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliderVolStateChanged(evt);
            }
        });
        volumen.add(sliderVol, java.awt.BorderLayout.CENTER);

        opciones.add(volumen);

        general.add(opciones, java.awt.BorderLayout.CENTER);

        botones.setBackground(java.awt.Color.darkGray);
        botones.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.white, 2));
        botones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 275, 5));

        volver.setBackground(new java.awt.Color(204, 204, 204));
        volver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        volver.setText("<VOLVER");
        volver.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });
        botones.add(volver);

        restaurar.setBackground(new java.awt.Color(204, 204, 204));
        restaurar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        restaurar.setText("RESTAURAR");
        restaurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restaurarActionPerformed(evt);
            }
        });
        botones.add(restaurar);

        general.add(botones, java.awt.BorderLayout.PAGE_END);

        titulo.setBackground(java.awt.Color.white);
        titulo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        titulo.setForeground(java.awt.Color.orange);
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("CONFIGURACIÓN SONIDO");
        titulo.setBorder(new javax.swing.border.MatteBorder(null));
        general.add(titulo, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(general, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void checkVolAutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkVolAutoActionPerformed
        controlador.setActivado(checkVolAuto.isSelected());
    }//GEN-LAST:event_checkVolAutoActionPerformed

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        controlador.procesaVolver();
    }//GEN-LAST:event_volverActionPerformed

    private void sliderVolStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliderVolStateChanged
        controlador.cambioVolumen(sliderVol.getValue());
    }//GEN-LAST:event_sliderVolStateChanged

    private void restaurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restaurarActionPerformed
        controlador.restauracion();
    }//GEN-LAST:event_restaurarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel botones;
    private javax.swing.JCheckBox checkVolAuto;
    private javax.swing.JPanel general;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JPanel opciones;
    private javax.swing.JButton restaurar;
    private javax.swing.JSlider sliderVol;
    private javax.swing.JPanel textoVolAuto;
    private javax.swing.JPanel textoVolumen;
    private javax.swing.JLabel titulo;
    private javax.swing.JPanel volAuto;
    private javax.swing.JPanel volumen;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables
/**
 * Vuelve al menu principal
 * @see my.teleVista.StateMachine
 */
    void volverMenu() {
        Main.television.mostrarMenu();
    }
/**
 * Pone los valores por defecto de la pestaña de sonido.
 * @see ModeloT#getVolAuto() 
 * @see ModeloT#getVolumen() 
 */
    void restaura() {
        checkVolAuto.setSelected(modelo.getVolAuto());
        sliderVol.setValue(modelo.getVolumen());
    }
}
