package my.teleVista;

import javax.swing.JFrame;
import my.teleModelo.ModeloT;

/**
 * Maquina de estados de la aplicacion.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloT
 * @see VistaMenu
 * @see VistaSonido
 * @see VistaImagen
 * @see VistaC
 */
public final class StateMachine {
    private JFrame currentState;
    private final ModeloT modelo;
/**
 * Constructor de la maquina de estados.
 * @param modelo El modelo usado por la aplicacion.
 */
    public StateMachine(ModeloT modelo) {
        this.modelo=modelo;
        mostrarMenu();
    }
/**
 * Cambia la ventana al menu principal.
 */   
    public void mostrarMenu(){
        java.awt.EventQueue.invokeLater(() -> {
            if(currentState!=null){
                currentState.dispose();
            }
            currentState=new VistaMenu(modelo);
            currentState.setVisible(true);
        });
    }
    /**
     * Cambia la ventana a la de configuracion de canales.
     */
    public void mostrarCanales(){
        java.awt.EventQueue.invokeLater(() -> {
            if(currentState!=null){
                currentState.dispose();
            }
            currentState=new VistaC(modelo);
            currentState.setVisible(true);
        });
    }
    /**
     * Cambia la ventana a la de configuracion de imagen.
     */
    public void mostrarImagen(){
        java.awt.EventQueue.invokeLater(() -> {
            if(currentState!=null){
                currentState.dispose();
            }
            currentState=new VistaImagen(modelo);
            currentState.setVisible(true);
        });
    }
    /**
     * Cambia la ventana a la de configuracion de sonido.
     */
    public void mostrarSonido(){
        java.awt.EventQueue.invokeLater(() -> {
            if(currentState!=null){
                currentState.dispose();
            }
            currentState=new VistaSonido(modelo);
            currentState.setVisible(true);
        });
    }
}
