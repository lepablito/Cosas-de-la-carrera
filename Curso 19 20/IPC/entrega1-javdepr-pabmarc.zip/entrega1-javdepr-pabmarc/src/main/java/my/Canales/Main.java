package my.Canales;

import my.canalesVista.VistaC;
/**
 * Clase Main de la aplicación.
 * 
 * @author javdepr
 * @author pabmarc
 */
public class Main {
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new VistaC().setVisible(true);
            }
        });
    }
}
