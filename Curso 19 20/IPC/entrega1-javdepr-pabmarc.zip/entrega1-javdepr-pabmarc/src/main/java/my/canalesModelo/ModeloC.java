package my.canalesModelo;

import java.util.ArrayList;
import my.Canales.Canal;
/**
 * Modelo de la interfaz sencilla del televisor
 * 
 * @author javdepr
 * @author pablm
 * 
 * @see my.canalesVista.VistaC
 * @see my.canalesVista.ControladorC
 * @see my.Canales.Canal
 */
public class ModeloC {
    private ArrayList<Canal> listaCanales;
    private ArrayList<String>canalesFav;
    private int estado;
    private int canalActual;
    private int canalEdit;
    /**
     * Constructor del modelo donde se inicializa la lista de canales con todos los canales, el estado de la aplicación (0=VER), canal actual en la zona de visionado y canal en edición.
     */
    public ModeloC(){
        listaCanales=new ArrayList<>();
        canalesFav=new ArrayList<>();
        listaCanales.add(new Canal("La 1", "src/main/java/my/canalesVista/la1.png"));
        listaCanales.add(new Canal("La 2", "src/main/java/my/canalesVista/la2.png"));
        listaCanales.add(new Canal("Antena 3", "src/main/java/my/canalesVista/antena3.png"));
        listaCanales.add(new Canal("Cuatro", "src/main/java/my/canalesVista/cuatro.png"));
        listaCanales.add(new Canal("Telecinco", "src/main/java/my/canalesVista/telecinco.png"));
        listaCanales.add(new Canal("La Sexta", "src/main/java/my/canalesVista/lasexta.png"));
        estado=0;
        canalActual=1;
        canalEdit=0;
    }
    /**
     * Consulta el estado de la aplicación.
     * 
     * @return El estado de la aplicación: 0=VER 1=ORDENAR 2=FAVORITOS 3=EDITAR
     */
    public int getEstado(){
        return estado;
    }
    /**
     * Consulta el canal en la zona de visonado.
     * 
     * @return El canal que aparece actualmente en la zona de visionado.
     */
    public int getCanalActual(){
        return canalActual;
    }
    /**
     * Consulta el canal en la zona de edición.
     * 
     * @return El canal que está en edición. 
     */
    public int getCanalEdit(){
        return canalEdit;
    }
    /**
     * Consulta la lista de canales.
     * 
     * @return La lista de canales.
     */
    public ArrayList<Canal>getListaCanales(){
        return listaCanales;
    }
    /**
     * Consulta la lista de canales favoritos.
     * 
     * @return La lista de canales favoritos.
     */
    public ArrayList<String>getCanalesFav(){
        return canalesFav;
    }
    /**
     * Cambia el estado de la aplicación.
     * 
     * @param estado Estado de la aplicación: 0=VER 1=ORDENAR 2=FAVORITOS 3=EDITAR.
     */
    public void setEstado(int estado){
        this.estado=estado;
    }
    /**
     * Cambia el canal que se está viendo en la zona de visionado.
     * 
     * @param canalActual Posición del canal que se está visionando en la lista de canales.
     */
    public void setCanalActual(int canalActual){
        this.canalActual=canalActual;
    }
    /**
     * Cambia el canal que se está editando.
     * 
     * @param canalEdit Posición del canal que se está editando en la lista de canales.
     */
    public void setCanalEdit(int canalEdit){
        this.canalEdit=canalEdit;
    }
    /**
     * Añade el nombre de un canal a la lista de favoritos.
     * 
     * @param num_canal Posición del canal en la lista de canales.
     * 
     * @see my.Canales.Canal#getNombre() 
     */
    public void addCanalFav(int num_canal){
        canalesFav.add(listaCanales.get(num_canal).getNombre());
    }
    /**
     * Elimina el nombre de un canal de la lista de favoritos.
     * 
     * @param num_canal Posicón del nombre del canal en la lista de favoritos.
     */
    public void deleteCanalFav(int num_canal){
        canalesFav.remove(num_canal);
    }
    /**
     * Cambia el orden de dos canales en la lista de canales.
     * 
     * @param canal1 Primer canal a cambiar.
     * @param canal2 Segundo canal a cambiar.
     */
    public void setOrden(Canal canal1, Canal canal2){
        int posicion1 = listaCanales.indexOf(canal1);
        int posicion2 = listaCanales.indexOf(canal2);
        listaCanales.set(posicion1, canal2);
        listaCanales.set(posicion2, canal1);
    }
    /**
     * Cambia el estado de activación de un canal.
     * 
     * @param activ True si se activa, False si se desactiva.
     * @param num Posición del canal en la lista de canales.
     * 
     * @see my.Canales.Canal#setActivado(boolean) 
     */
    public void activarCanal(boolean activ,int num){
        listaCanales.get(num).setActivado(activ);
    }
    /**
     * Cambia el nombre de un canal en la lista de canales.
     * 
     * @param name El nuevo nombre que se va a poner.
     * 
     * @see my.Canales.Canal#getNombre() 
     * @see my.Canales.Canal#setNombre(java.lang.String) 
     */
    public void setName(String name){
        int index;
        String old_name = listaCanales.get(canalEdit).getNombre();
        listaCanales.get(canalEdit).setNombre(name);
        index = canalesFav.indexOf(old_name);
        if (index != -1){
            canalesFav.set(index, name);
        }
    }
    /**
     * Limpia la lista entera de favoritos.
     */
    public void clearListaFav(){
        canalesFav.clear();
    }
}
