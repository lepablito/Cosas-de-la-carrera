package my.canalesVista;

import java.util.ArrayList;
import my.Canales.Canal;
import my.canalesModelo.ModeloC;
/**
 * Controlador de la interfaz sencilla del televisor.
 * 
 * @author javdepr
 * @author pabmarc
 * 
 * @see ModeloC
 * @see VistaC
 * @see my.Canales.Canal
 */
public class ControladorC {
    private VistaC vista;
    private ModeloC modelo;
    private Canal canal1;
    private Canal canal2;
    /**
     * Constructor del controlador, se declaran el modelo usado y la vista de la aplicación así como dos variables Canal.
     * 
     * @param v La vista usada en la aplicación.
     * @param m El modelo de la aplicación.
     */
    public ControladorC(VistaC v, ModeloC m){
        vista=v;
        modelo=m;
        canal1=null;
        canal2=null;
    }
    /**
    * Llama a los métodos del modelo y la vista para cambiar el canal seleccionado en la zona de visionado de la televisión así como el canal de edición.
    * 
    * @param num Posición del canal elegido en la lista de canales.
    * 
    * @see ModeloC#setCanalActual(int) 
    * @see ModeloC#setCanalEdit(int) 
    * @see VistaC#setCanal(int) 
    * @see VistaC#setCanalEdit(int) 
    */
    public void setCanal(int num){
        modelo.setCanalActual(num+1);
        vista.setCanal(num);    
        modelo.setCanalEdit(num);
        vista.setCanalEdit(num);
    }
    /**
     * Llama a los métodos del modelo y la vista para cambiar el estado de la aplicación a VER, ORDENAR, FAVORITOS, EDITAR y cambiar el botón pulsado.
     * 
     * @param num El estado al que cambia la aplicación: 0=VER 1=ORDENAR 2=FAVORITOS 3=EDITAR
     * 
     * @see ModeloC#setEstado(int) 
     * @see VistaC#restaura()
     * @see VistaC#eligeBoton(int) 
     */
    public void setEstado(int num){
        modelo.setEstado(num);
        if(canal1!=null){
            canal1=null;
            vista.restaura();
        }
        vista.eligeBoton(num);
    } 
    /**
     * Llama a los métodos del modelo y la vista para actualizar el orden de los canales.
     * 
     * @param num Posicion del canal en la lista de canales.
     * 
     * @see ModeloC#setOrden(my.Canales.Canal, my.Canales.Canal) 
     * @see ModeloC#getListaCanales() 
     * @see VistaC#senalCanal(int)
     * @see VistaC#actualizaCanales() 
     * @see VistaC#restaura() 
     */
    public void cambiaOrden(int num){
        if(canal1==null){
            canal1=modelo.getListaCanales().get(num);
            vista.senalCanal(num);
        }else if(canal2==null){
            canal2=modelo.getListaCanales().get(num);
        }
        if (canal1!=null && canal2!=null && canal1!=canal2){
            modelo.setOrden(canal1, canal2);
            canal1=null;
            canal2=null;
            vista.actualizaCanales();
            vista.restaura();
        }
        if(canal1==canal2){
            canal1=null;
            canal2=null;
            vista.restaura();
        }
    }
    /**
     * Llama a los métodos del modelo y la vista para añadir un canal a la lista de favoritos.
     * 
     * @param num Posición del canal en la lista de canales.
     * 
     * @see ModeloC#addCanalFav(int) 
     * @see VistaC#addCanalFav(int) 
     */
    public void addFavoritos(int num){
        modelo.addCanalFav(num);
        vista.addCanalFav(num);
    }   
    /**
     * Llama a los métodos del modelo y la vista para cambiar el canal editado.
     * 
     * @param num Posición del canal en la lista de canales.
     * 
     * @see ModeloC#setCanalEdit(int) 
     * @see VistaC#setCanalEdit(int) 
     */
    public void setEditado(int num){
        modelo.setCanalEdit(num);
        vista.setCanalEdit(num);
    }
    /**
     * Llama al método del modelo para actualizar el estado de activacion del canal en edición.
     * 
     * @param activado True si está activado, False si está desactivado
     * 
     * @see ModeloC#activarCanal(boolean, int) 
     */
    public void setActivado(boolean activado){
        modelo.activarCanal(activado, modelo.getCanalEdit());
    }
    /**
     * Llama a los métodos del modelo y la vista para actualizar el nombre del canal.
     * 
     * @param nombre Nombre nuevo del canal.
     * 
     * @see ModeloC#setName(java.lang.String) 
     */
    public void setNombre(String nombre){
        vista.setNombre(nombre);
        modelo.setName(nombre);
    }
    /**
     * Llama a los métodos del modelo y de la vista para borrar el nombre de canal elegido de la lista de favoritos.
     * 
     * @param num Posicion del canal en la lista de canales favoritos.
     * 
     * @see ModeloC#deleteCanalFav(int) 
     * @see VistaC#deleteCanalFav(int) 
     */
    public void procesaBorra(int num){
        modelo.deleteCanalFav(num);
        vista.deleteCanalFav(num);
    }
    /**
     * Llama a los métodos del modelo y de la vista para borrar todos los nommbres de canal de la lista de favoritos.
     * 
     * @see ModeloC#clearListaFav() 
     * @see VistaC#clearListaFav() 
     */
    public void borraTodo(){
        modelo.clearListaFav();
        vista.clearListaFav();
    }
    /**
     * Comprueba si el nuevo nombre ya esta siendo utilizado por otro canal.
     * 
     * @param nombre El nuevo nombre que se quiere dar al canal
     * @return si dicho nombre ya esta en uso
     */
    public boolean nombreUsado(String nombre){
        boolean usado = false;
        for (Canal canal: modelo.getListaCanales()){
            if (canal.getNombre().equals(nombre)){
                usado = true;
            }
        }
        return usado;
    }
}
